package de.uhd.ifi.pokemonmanager.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;
import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Competition;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;
import de.uhd.ifi.pokemonmanager.data.Trainer;
import de.uhd.ifi.pokemonmanager.data.Type;
import de.uhd.ifi.pokemonmanager.storage.SerialStorage;
import de.uhd.ifi.pokemonmanager.ui.adapter.PokemonAdapter;
import de.uhd.ifi.pokemonmanager.ui.util.RecyclerViewUtil;

public class MainActivity extends AppCompatActivity
{
    public static final String DETAIL_POKEMON = "detail_pokemon";
    private static final SerialStorage STORAGE = SerialStorage.getInstance();
    private static boolean wasWiped = false;

    private RecyclerView pokemonList;
    private PokemonAdapter pokemonAdapter;
    private View extendedView = null;
    private Toolbar mainToolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         mainToolbar = findViewById(R.id.detailsToolbar);
        setSupportActionBar(mainToolbar);

        pokemonList = findViewById(R.id.pokemonList);

        FloatingActionButton newPokemonButton = findViewById(R.id.newPokemonButton);
        newPokemonButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                createPokemon();
            }
        });

        setupList();
    }

    private void createPokemon()
    {
        Intent intent = new Intent(this, CreatePokemonActivity.class);
        startActivity(intent);
    }


    private void setupList()
    {
        final List<Pokemon> data = STORAGE.getAllPokemon();
        pokemonAdapter = new PokemonAdapter(this, data);

        final RecyclerView.LayoutManager manager = RecyclerViewUtil.createLayoutManager(this);

        pokemonList.setLayoutManager(manager);
        pokemonList.setAdapter(pokemonAdapter);
    }


    private void createSampleDataIfNecessary()
    {
        if (STORAGE.getAllPokemon().isEmpty())
        {
            STORAGE.clear(this);

            Trainer t1 = new Trainer("Alisa", "Traurig");
            Trainer t2 = new Trainer("Petra", "Lustig");
            Pokemon p1 = new Pokemon("Shiggy", Type.WATER);
            Pokemon p2 = new Pokemon("Rettan", Type.POISON);
            Pokemon p3 = new Pokemon("Glurak", Type.FIRE);
            Pokemon p4 = new Pokemon("Keks", Type.FIRE);

            t1.addPokemon(p1);
            t1.addPokemon(p2);
            t2.addPokemon(p3);
            t2.addPokemon(p4);

            p1.setSwapAllow(true);
            p2.setSwapAllow(true);
            p3.setSwapAllow(true);
            p4.setSwapAllow(true);

            STORAGE.update(p1);
            STORAGE.update(p2);
            STORAGE.update(p3);
            STORAGE.update(p4);
            STORAGE.update(t1);
            STORAGE.update(t2);
            STORAGE.saveAll(this);

            Swap s1 = new Swap();
            s1.execute(p1, p3);
            Swap s2 = new Swap();
            s2.execute(p1, p2);
            Swap s3 = new Swap();
            s3.execute(p1, p2);
            Swap s4 = new Swap();
            s4.execute(p1, p2);
            Swap s5 = new Swap();
            s4.execute(p1, p2);
            Swap s6 = new Swap();
            s4.execute(p1, p2);

            Competition c1 = new Competition();
            c1.execute(p1, p2);

            STORAGE.update(p1);
            STORAGE.update(p2);
            STORAGE.update(p3);
            STORAGE.update(p4);
            STORAGE.update(t1);
            STORAGE.update(t2);
            STORAGE.update(s1);
            STORAGE.update(s2);
            STORAGE.update(s3);
            STORAGE.update(s4);
            STORAGE.update(s5);
            STORAGE.update(s6);
            STORAGE.update(c1);
            STORAGE.saveAll(this);
        }
    }

    @Override
    protected void onStart()
    {
        super.onStart();
        // wipe storage initially
        if(!wasWiped)
        {
            STORAGE.clear(this);
            wasWiped = true;
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        STORAGE.loadAll(this);
        createSampleDataIfNecessary();
        pokemonAdapter.refresh();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        STORAGE.saveAll(this);
    }

    public void extendItem(View view)
    {
        if (view != null)
        {
            Button details = view.findViewById(R.id.detailsButton);
            Button delete = view.findViewById(R.id.removeButton);

            if (details.getVisibility() == View.VISIBLE)
            {
                details.setVisibility(View.GONE);
                delete.setVisibility(View.GONE);
                extendedView = null;
            }
            else
            {
                extendItem(extendedView);
                details.setVisibility(View.VISIBLE);
                delete.setVisibility(View.VISIBLE);
                extendedView = view;
            }
        }
    }

    private int getPokemonIdFromListButton(View button)
    {
        View parent = (View) button.getParent();
        TextView tV = parent.findViewById(R.id.pokemonId);

        return Integer.parseInt(tV.getText().toString().substring(2));
    }

    public void removePokemon(View view)
    {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Do you really want to remove this Pokemon?");
        alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface arg0, int arg1)
            {
                extendItem((View) view.getParent());
                int pokemonId = getPokemonIdFromListButton(view);
                STORAGE.remove(STORAGE.getPokemonById(pokemonId));
                STORAGE.saveAll(getBaseContext());
                pokemonAdapter.refresh();
            }
        });

        alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                // Nothing to do here...
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void changeToDetailsView(View view)
    {
        int id = getPokemonIdFromListButton(view);
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra("pokemon", (Parcelable) STORAGE.getPokemonById(id));
        startActivity(intent);
    }
}
