package de.uhd.ifi.pokemonmanager.data;

public enum Type {
    FIRE, WATER, POISON
}
