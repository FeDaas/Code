package de.uhd.ifi.pokemonmanager.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Competition;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;
import de.uhd.ifi.pokemonmanager.data.Trainer;
import de.uhd.ifi.pokemonmanager.data.Type;
import de.uhd.ifi.pokemonmanager.storage.SerialStorage;
import de.uhd.ifi.pokemonmanager.ui.adapter.CompetitionAdapter;
import de.uhd.ifi.pokemonmanager.ui.adapter.SwapAdapter;
import de.uhd.ifi.pokemonmanager.ui.util.RecyclerViewUtil;

public class DetailActivity extends AppCompatActivity
{
    private static final SerialStorage STORAGE = SerialStorage.getInstance();

    private Pokemon pokemon;
    private TextView pokemonName;
    private TextView pokemonID;
    private ImageView pokemonType;
    private Spinner trainerSpinner;
    private CheckBox swapAllowedChecker;

    private RecyclerView swapList;
    private RecyclerView competitionsList;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        swapList = findViewById(R.id.swapList);
        competitionsList = findViewById(R.id.competitionList);

        pokemon = getIntent().getParcelableExtra("pokemon");
        pokemonName = findViewById(R.id.detailsPokemonName);
        pokemonID = findViewById(R.id.detailsPokemonId);
        pokemonType = findViewById(R.id.detailsPokemonType);
        swapAllowedChecker = findViewById(R.id.swapCheckbox);

        setText();
        setupSwaps();
        setupCompetitions();
        addItemsOnTrainerSpinner();
    }

    private void setText()
    {
        pokemonName.setText(pokemon.getName());
        pokemonName.setFocusable(false);
        pokemonName.setClickable(false);

        String text = "# " + pokemon.getId();
        pokemonID.setText(text);

        Type type = pokemon.getType();

        switch (type)
        {
            case FIRE:
                pokemonType.setImageResource(R.drawable.fire_small_selected);
                break;

            case WATER:
                pokemonType.setImageResource(R.drawable.water_small_selected);
                break;

            case POISON:
                pokemonType.setImageResource(R.drawable.skull_small_selected);
                break;
        }
    }

    private List<List<String>> makeSwapStrings(List<Swap> swaps)
    {
        List<List<String>> stringList = new ArrayList<>();

        for (Swap swap : swaps)
        {
            List<String> strings = new ArrayList<>();
            String partner = "[Deleted]";

            if (swap.getSourcePokemon() != null && swap.getTargetPokemon() != null)
            {
                String sourcePokemon = swap.getSourcePokemon().getName();
                String targetPokemon = swap.getTargetPokemon().getName();

                partner = (pokemon.getId() == swap.getSourcePokemon().getId() ? targetPokemon : sourcePokemon);
            }

            strings.add(partner);
            strings.add(swap.getDate().toString());
            stringList.add(strings);
        }

        return stringList;
    }

    private void setupSwaps()
    {
        swapAllowedChecker.setChecked(pokemon.isSwapAllow());

        final List<List<String>> data = makeSwapStrings(pokemon.getSwaps());
        SwapAdapter swapAdapter = new SwapAdapter(this, data);

        final RecyclerView.LayoutManager manager = RecyclerViewUtil.createLayoutManager(this);

        swapList.setLayoutManager(manager);
        swapList.setAdapter(swapAdapter);
    }

    private List<List<String>> makeCompetitionStrings(List<Competition> competitions)
    {
        List<List<String>> stringList = new ArrayList<>();

        for (Competition competition : competitions)
        {
            List<String> strings = new ArrayList<>();
            String result = (competition.getWinner() == null ? "Lost" : "Won");
            String partner = "[Deleted]";

            if (competition.getSourcePokemon() != null && competition.getTargetPokemon() != null)
            {
                result = (pokemon.getId() == competition.getWinner().getId() ? "Won" : "Lost");

                String sourcePokemon = competition.getSourcePokemon().getName();
                String targetPokemon = competition.getTargetPokemon().getName();
                partner = (pokemon.getName().equals(sourcePokemon) ? targetPokemon : sourcePokemon);

            }

            strings.add(result);
            strings.add(partner);
            strings.add(competition.getDate().toString());
            stringList.add(strings);
        }

        return stringList;
    }

    private void setupCompetitions()
    {
        final List<List<String>> data = makeCompetitionStrings(pokemon.getCompetitions());
        CompetitionAdapter competitionAdapter = new CompetitionAdapter(this, data);

        final RecyclerView.LayoutManager manager = RecyclerViewUtil.createLayoutManager(this);

        competitionsList.setLayoutManager(manager);
        competitionsList.setAdapter(competitionAdapter);
    }

    private void addItemsOnTrainerSpinner()
    {
        trainerSpinner = findViewById(R.id.detailsPokemonTrainer);
        trainerSpinner.setSelection(pokemon.getTrainer().getId());
        trainerSpinner.setEnabled(false);
        ArrayAdapter<Trainer> trainerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, STORAGE.getAllTrainer());
        trainerSpinner.setAdapter(trainerAdapter);
    }

    private void makeUpdatedSettingsToast()
    {
        Toast.makeText(this, "Saved Changes", Toast.LENGTH_SHORT).show();
    }

    public void onEditNameButtonClicked(View view)
    {
        if (pokemonName.isFocusable())
        {
            if (!pokemonName.getText().toString().equals(""))
            {
                pokemonName.setClickable(false);
                pokemonName.setFocusable(false);
                ((ImageButton) view).setImageResource(android.R.drawable.ic_menu_edit);

                pokemon.setName(pokemonName.getText().toString());
                STORAGE.update(pokemon);
                STORAGE.saveAll(getBaseContext());

                makeUpdatedSettingsToast();
            }
            else
            {
                Toast.makeText(this, "Name can't be empty!", Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            pokemonName.setClickable(true);
            pokemonName.setFocusable(true);
            pokemonName.setFocusableInTouchMode(true);

            pokemonName.requestFocus();
            ((ImageButton) view).setImageResource(android.R.drawable.checkbox_on_background);
        }
    }

    public void onEditTypeButtonClicked(View view)
    {
        switch (pokemon.getType())
        {
            case POISON:
                pokemonType.setImageResource(R.drawable.water_small_selected);
                pokemon.setType(Type.WATER);
                STORAGE.update(pokemon);
                STORAGE.saveAll(getBaseContext());
                makeUpdatedSettingsToast();
                break;

            case WATER:
                pokemonType.setImageResource(R.drawable.fire_small_selected);
                pokemon.setType(Type.FIRE);
                STORAGE.update(pokemon);
                STORAGE.saveAll(getBaseContext());
                makeUpdatedSettingsToast();
                break;

            case FIRE:
                pokemonType.setImageResource(R.drawable.skull_small_selected);
                pokemon.setType(Type.POISON);
                STORAGE.update(pokemon);
                STORAGE.saveAll(getBaseContext());
                makeUpdatedSettingsToast();
                break;

             default:
                break;
        }
    }

    public void onEditTrainerButtonClicked(View view)
    {
        if (trainerSpinner.isEnabled())
        {
            trainerSpinner.setEnabled(false);
            ((ImageButton) view).setImageResource(android.R.drawable.ic_menu_edit);
            pokemon.setTrainer((Trainer) trainerSpinner.getSelectedItem());
            STORAGE.update(pokemon);
            STORAGE.saveAll(getBaseContext());
            makeUpdatedSettingsToast();
        }
        else
        {
            trainerSpinner.setEnabled(true);
            ((ImageButton) view).setImageResource(android.R.drawable.checkbox_on_background);
        }
    }

    public void onSwapChecked(View view)
    {
        pokemon.setSwapAllow(swapAllowedChecker.isChecked());
        STORAGE.update(pokemon);
        STORAGE.saveAll(getBaseContext());
        makeUpdatedSettingsToast();
    }
}
