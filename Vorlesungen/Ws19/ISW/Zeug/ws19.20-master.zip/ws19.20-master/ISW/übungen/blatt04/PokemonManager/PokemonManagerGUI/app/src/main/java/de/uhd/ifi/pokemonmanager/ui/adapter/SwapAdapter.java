package de.uhd.ifi.pokemonmanager.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import java.util.List;
import java.util.Objects;

import de.uhd.ifi.pokemonmanager.R;

import static java.util.stream.Collectors.toList;


public class SwapAdapter extends Adapter<SwapHolder>
{
    private LayoutInflater inflater;
    private List<List<String>> originalData;
    private List<List<String>> filteredData;

    public SwapAdapter(final Context context, final List<List<String>> originalData)
    {
        this.inflater = LayoutInflater.from(context);
        this.originalData = originalData;
        this.filteredData = this.originalData.stream().filter(Objects::nonNull).collect(toList());
    }

    @NonNull
    @Override
    public SwapHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        final View itemView = inflater.inflate(R.layout.listitem_swap, parent, false);
        return new SwapHolder(itemView);
    }

    @Override
    public  void onBindViewHolder(@NonNull SwapHolder holder, int position)
    {
        holder.setSwap(filteredData.get(position));
    }

    @Override
    public int getItemCount()
    {
        return filteredData.size();
    }

    public void refresh()
    {
        this.filteredData = originalData.stream().filter(Objects::nonNull).collect(toList());
        notifyDataSetChanged();;
    }
}


class SwapHolder extends ViewHolder
{
    private final TextView swapText;
    private final TextView swapDate;

    SwapHolder(@NonNull View itemView)
    {
        super(itemView);
        swapText = itemView.findViewById(R.id.swapText);
        swapDate = itemView.findViewById(R.id.swapTime);
        itemView.setTag(this);
    }

    void setSwap(List<String> stringList)
    {
        if (stringList != null)
        {
            swapText.setText("Traded with " + stringList.get(0));
            swapDate.setText("Time: " + stringList.get(1));
        }
    }
}