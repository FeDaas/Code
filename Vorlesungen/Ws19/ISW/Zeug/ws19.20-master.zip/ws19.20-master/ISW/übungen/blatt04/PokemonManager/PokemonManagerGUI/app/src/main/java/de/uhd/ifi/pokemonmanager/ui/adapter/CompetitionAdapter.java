package de.uhd.ifi.pokemonmanager.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import java.util.List;
import java.util.Objects;

import de.uhd.ifi.pokemonmanager.R;

import static java.util.stream.Collectors.toList;


public class CompetitionAdapter extends Adapter<CompetitionHolder>
{
    private LayoutInflater inflater;
    private List<List<String>> originalData;
    private List<List<String>> filteredData;

    public CompetitionAdapter(final Context context, final List<List<String>> originalData)
    {
        this.inflater = LayoutInflater.from(context);
        this.originalData = originalData;
        this.filteredData = this.originalData.stream().filter(Objects::nonNull).collect(toList());
    }

    @NonNull
    @Override
    public CompetitionHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        final View itemView = inflater.inflate(R.layout.listitem_competition, parent, false);
        return new CompetitionHolder(itemView);
    }

    @Override
    public  void onBindViewHolder(@NonNull CompetitionHolder holder, int position)
    {
        holder.setCompetition(filteredData.get(position));
    }

    @Override
    public int getItemCount()
    {
        return filteredData.size();
    }

    public void refresh()
    {
        this.filteredData = originalData.stream().filter(Objects::nonNull).collect(toList());
        notifyDataSetChanged();;
    }
}

class CompetitionHolder extends ViewHolder
{
    private final TextView competitionText;
    private final TextView competitionDate;

    CompetitionHolder(@NonNull View itemView)
    {
        super(itemView);
        competitionText = itemView.findViewById(R.id.competitionText);
        competitionDate = itemView.findViewById(R.id.competitionTime);
        itemView.setTag(this);
    }

    void setCompetition(List<String> stringList)
    {
        if (stringList != null)
        {
            competitionText.setText(stringList.get(0) + " against " + stringList.get(1));
            competitionDate.setText("Time: " + stringList.get(2));
        }
    }
}