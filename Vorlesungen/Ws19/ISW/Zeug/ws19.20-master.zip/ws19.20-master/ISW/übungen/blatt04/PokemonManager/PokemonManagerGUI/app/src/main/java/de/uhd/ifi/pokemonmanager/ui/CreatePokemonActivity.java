package de.uhd.ifi.pokemonmanager.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Trainer;
import de.uhd.ifi.pokemonmanager.data.Type;
import de.uhd.ifi.pokemonmanager.storage.SerialStorage;


public class CreatePokemonActivity extends AppCompatActivity
{
    private static final SerialStorage STORAGE = SerialStorage.getInstance();

    private Type type = null;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_pokemon);

        addItemsOnTrainerSpinner();
    }

    public void addItemsOnTrainerSpinner()
    {
        Spinner trainerSpinner = findViewById(R.id.trainers);
        ArrayAdapter<Trainer> trainerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, STORAGE.getAllTrainer());
        trainerSpinner.setAdapter(trainerAdapter);
    }

    public void createPokemon(View view)
    {
        if(checkdata())
        {
            Pokemon newPokemon = new Pokemon(((EditText) findViewById(R.id.Name)).getText().toString(), type);
            (((Trainer) ((Spinner) findViewById(R.id.trainers)).getSelectedItem())).addPokemon(newPokemon);
            STORAGE.update(newPokemon);
            STORAGE.saveAll(getBaseContext());
            finish();
        }
    }

    private boolean checkdata()
    {
        Context context = getApplicationContext();
        boolean allTrue = true;

        String name = ((EditText)findViewById(R.id.Name)).getText().toString();
        if (name.equals(""))
        {
            Toast.makeText(context, "Enter a name first", Toast.LENGTH_SHORT).show();
            allTrue = false;
        }
        if(type == null)
        {
            Toast.makeText(context, "Select type first", Toast.LENGTH_SHORT).show();
            allTrue = false;
        }

        return allTrue;
    }

    public void onTypeClicked(View view)
    {
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId())
        {
            case R.id.selFire:
                if (checked)
                {
                    type = Type.FIRE;

                    ((RadioButton) view).setButtonDrawable(R.drawable.fire_small_selected);
                    ((RadioButton) findViewById(R.id.selPoison)).setButtonDrawable(R.drawable.skull_small);
                    ((RadioButton) findViewById(R.id.selWater)).setButtonDrawable(R.drawable.water_small);
                }
                break;

            case R.id.selWater:
                if (checked)
                {
                    type = Type.WATER;

                    ((RadioButton) view).setButtonDrawable(R.drawable.water_small_selected);
                    ((RadioButton) findViewById(R.id.selPoison)).setButtonDrawable(R.drawable.skull_small);
                    ((RadioButton) findViewById(R.id.selFire)).setButtonDrawable(R.drawable.fire_small);
                }
                break;

            case R.id.selPoison:
                if (checked)
                {
                    type = Type.POISON;

                    ((RadioButton) view).setButtonDrawable(R.drawable.skull_small_selected);
                    ((RadioButton) findViewById(R.id.selFire)).setButtonDrawable(R.drawable.fire_small);
                    ((RadioButton) findViewById(R.id.selWater)).setButtonDrawable(R.drawable.water_small);
                }
                break;

             default:
                break;
        }
    }
}
