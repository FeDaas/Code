package de.moviemanager.data;

public interface Nameable {
    String name();
}
