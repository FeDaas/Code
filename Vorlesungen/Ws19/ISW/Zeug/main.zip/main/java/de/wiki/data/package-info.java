/**
 * Package containing both data classes {@link de.wiki.data.Actor} and {@link de.wiki.data.Film}
 *
 * <br><b>Author</b>: <a href="mailto:schustrchr@gmail.com">Ctoffer</a><br>
 */
package de.wiki.data;