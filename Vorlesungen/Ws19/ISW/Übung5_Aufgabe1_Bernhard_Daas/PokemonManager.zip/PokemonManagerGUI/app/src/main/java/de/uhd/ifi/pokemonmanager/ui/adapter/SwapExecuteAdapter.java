package de.uhd.ifi.pokemonmanager.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.annotation.NonNull;

import java.util.List;
import java.util.Objects;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Pokemon;

import static java.util.stream.Collectors.toList;


public class SwapExecuteAdapter extends Adapter<SwapExecuteHolder>
{
    private LayoutInflater inflater;
    private List<Pokemon> originalData;
    private List<Pokemon> filteredData;

    public SwapExecuteAdapter(final Context context, final List<Pokemon> originalData)
    {
        this.inflater = LayoutInflater.from(context);
        this.originalData = originalData;
        this.filteredData = this.originalData.stream().filter(Objects::nonNull).collect(toList());
    }

    @NonNull
    @Override
    public SwapExecuteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        final View itemView = inflater.inflate(R.layout.listitem_swap_fragment, parent, false);
        return new SwapExecuteHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SwapExecuteHolder holder, int position)
    {
        holder.setSwapExecute(filteredData.get(position));
    }

    @Override
    public int getItemCount()
    {
        return filteredData.size();
    }
}


class SwapExecuteHolder extends RecyclerView.ViewHolder
{
    private final TextView pname;
    private final TextView tname;
    private final RadioButton radioButton;
    private final ImageView type;

    SwapExecuteHolder(@NonNull View itemView)
    {
        super(itemView);
        pname = itemView.findViewById(R.id.swapPokemonName);
        tname = itemView.findViewById(R.id.swapExecuteTrainerName);
        radioButton = itemView.findViewById(R.id.radioButtonSwapExecute);
        type = itemView.findViewById(R.id.swapExecuteType);

        itemView.setTag(this);
    }

    void setSwapExecute(Pokemon pokemon)
    {
        if (pokemon != null)
        {
            pname.setText(pokemon.getName());
            tname.setText(pokemon.getTrainer().getFirstName() + " " + pokemon.getTrainer().getLastName());

            switch (pokemon.getType())
            {
                case FIRE:
                    type.setImageResource(R.drawable.type_fire_selected_small);
                    break;

                case WATER:
                    type.setImageResource(R.drawable.type_water_selected_small);
                    break;

                case POISON:
                    type.setImageResource(R.drawable.type_poison_selected_small);
                    break;

                default:
                    break;
            }
        }
    }
}