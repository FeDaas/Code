package de.uhd.ifi.pokemonmanager.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Competition;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Trainer;
import de.uhd.ifi.pokemonmanager.data.Type;
import de.uhd.ifi.pokemonmanager.storage.SerialStorage;
import de.uhd.ifi.pokemonmanager.ui.adapter.CompetitionAdapter;
import de.uhd.ifi.pokemonmanager.ui.adapter.SwapAdapter;
import de.uhd.ifi.pokemonmanager.ui.util.RecyclerViewUtil;
import de.uhd.ifi.pokemonmanager.ui.util.SwapFragment;

public class DetailActivity extends AppCompatActivity
{
    private static final SerialStorage STORAGE = SerialStorage.getInstance();
    private static Boolean colorIsSet = false;

    private Pokemon pokemon;
    private int editingMode = 0;
    private Boolean editMode = false;
    private ColorStateList fireColors;
    private ColorStateList waterColors;
    private ColorStateList poisonColors;
    private Type currentType;

    private Toolbar detailsToolbar;
    private FloatingActionButton editButton;
    private TextView pokemonName;
    private TextView pokemonID;
    private ImageView pokemonType;
    private Spinner trainerSpinner;
    private CheckBox swapAllowedChecker;
    private RecyclerView swapList;
    private RecyclerView competitionsList;

    private SwapAdapter swapAdapter;
    private CompetitionAdapter competitionAdapter;
    ArrayAdapter<Trainer> trainerAdapter;

    private SwapFragment swapFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        detailsToolbar = findViewById(R.id.detailsToolbar);
        setSupportActionBar(detailsToolbar);

        editButton = findViewById(R.id.editButton);

        swapList = findViewById(R.id.swapList);
        competitionsList = findViewById(R.id.competitionList);

        pokemon = getIntent().getParcelableExtra("pokemon");
        pokemonName = findViewById(R.id.detailsPokemonName);
        pokemonID = findViewById(R.id.detailsPokemonId);
        pokemonType = findViewById(R.id.detailsPokemonType);
        swapAllowedChecker = findViewById(R.id.swapCheckbox);

        currentType = pokemon.getType();

        setText();
        setupSwaps();
        setupCompetitions();
        setupColors();
        addItemsOnTrainerSpinner();
        updateToolbarColor();
    }

    private void setText()
    {
        pokemonName.setText(pokemon.getName());
        pokemonName.setFocusable(false);
        pokemonName.setClickable(false);

        String text = "# " + pokemon.getId();
        pokemonID.setText(text);

        Type type = pokemon.getType();

        switch (type)
        {
            case FIRE:
                pokemonType.setImageResource(R.drawable.ic_type_fire_selected);
                break;

            case WATER:
                pokemonType.setImageResource(R.drawable.ic_type_water_selected);
                break;

            case POISON:
                pokemonType.setImageResource(R.drawable.ic_type_poison_selected);
                break;
        }
    }

    private void setupSwaps()
    {
        swapAllowedChecker.setChecked(pokemon.isSwapAllow());
        swapAdapter = new SwapAdapter(this, pokemon);

        final RecyclerView.LayoutManager manager = RecyclerViewUtil.createLayoutManager(this);

        swapList.setLayoutManager(manager);
        swapList.setAdapter(swapAdapter);
    }

    private List<List<String>> makeCompetitionStrings(List<Competition> competitions)
    {
        List<List<String>> stringList = new ArrayList<>();

        for (Competition competition : competitions)
        {
            List<String> strings = new ArrayList<>();
            String result = (competition.getWinner() == null ? "Lost" : "Won");
            String partner = "[Deleted]";

            if (competition.getSourcePokemon() != null && competition.getTargetPokemon() != null)
            {
                result = (pokemon.getId() == competition.getWinner().getId() ? "Won" : "Lost");

                String sourcePokemon = competition.getSourcePokemon().getName();
                String targetPokemon = competition.getTargetPokemon().getName();
                partner = (pokemon.getName().equals(sourcePokemon) ? targetPokemon : sourcePokemon);

            }

            strings.add(result);
            strings.add(partner);
            strings.add(competition.getDate().toString());
            stringList.add(strings);
        }

        return stringList;
    }

    private void setupCompetitions()
    {
        final List<List<String>> data = makeCompetitionStrings(pokemon.getCompetitions());
        competitionAdapter = new CompetitionAdapter(this, data);

        final RecyclerView.LayoutManager manager = RecyclerViewUtil.createLayoutManager(this);

        competitionsList.setLayoutManager(manager);
        competitionsList.setAdapter(competitionAdapter);
    }

    private void setupColors()
    {
        fireColors = new ColorStateList(
                new int[][]{
                        new int[]{Color.parseColor("#820933")} //enabled
                },
                new int[] {Color.parseColor("#c42021")});

        waterColors = new ColorStateList(
                new int[][]{
                        new int[]{Color.parseColor("#17178a")} //enabled
                },
                new int[] {Color.parseColor("#415bc5")});

        poisonColors = new ColorStateList(
                new int[][]{
                        new int[]{Color.parseColor("#470a6b")} //enabled
                },
                new int[] {Color.parseColor("#6309b7")});
    }

    private void addItemsOnTrainerSpinner()
    {
        trainerSpinner = findViewById(R.id.detailsPokemonTrainer);
        trainerSpinner.setEnabled(false);
        trainerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, STORAGE.getAllTrainer());
        trainerSpinner.setAdapter(trainerAdapter);
        trainerSpinner.setSelection(pokemon.getTrainer().getId());
    }

    private void updateToolbarColor()
    {
        switch (currentType)
        {
            case FIRE:
                detailsToolbar.setBackgroundColor(Color.parseColor("#820933"));
                getWindow().setStatusBarColor(Color.parseColor("#c42021"));
                swapAllowedChecker.setButtonTintList(fireColors);
                break;

            case WATER:
                detailsToolbar.setBackgroundColor(Color.parseColor("#17178a"));
                getWindow().setStatusBarColor(Color.parseColor("#415bc5"));
                swapAllowedChecker.setButtonTintList(waterColors);
                break;

            case POISON:
                detailsToolbar.setBackgroundColor(Color.parseColor("#470a6b"));
                getWindow().setStatusBarColor(Color.parseColor("#6309b7"));
                swapAllowedChecker.setButtonTintList(poisonColors);
                break;

            default:
                break;
        }
    }

    private void makeUpdatedSettingsToast()
    {
        Toast.makeText(this, "Saved Changes", Toast.LENGTH_SHORT).show();
    }

    private void makeNotSwapableToast()
    {
        Toast.makeText(this, "Swap not allowed!", Toast.LENGTH_SHORT).show();
    }

    private void createSwapFragment()
    {
        if (pokemon.isSwapAllow())
        {
            FragmentManager fragmentManager = getSupportFragmentManager();
            swapFragment = SwapFragment.newInstance(pokemon);
            swapFragment.show(fragmentManager, "HI");
        }
        else
        {
            makeNotSwapableToast();
        }
    }

    public void removeFragmentAndUpdate()
    {
        if (swapFragment != null && swapFragment.getFragmentManager() != null)
        {
            swapAdapter.refresh();
            trainerSpinner.setSelection(trainerAdapter.getPosition(pokemon.getTrainer()));
            swapFragment.getFragmentManager().beginTransaction().remove(swapFragment).commit();
        }
    }

    public void switchMode(View view)
    {
        if (editingMode == 0)
        {
            editButton.setImageResource(R.drawable.ic_pokeball_swap_vec);
            editingMode = 1;

        }
        else
        {
            editButton.setImageResource(R.drawable.ic_pokeball_edit_vec);
            editingMode = 0;
        }

    }

    public void onEditButtonClicked(View view)
    {
        if (editingMode == 0)
        {
            editMode = !editMode;


            FloatingActionButton switchbutton =  ((View)view.getParent()).findViewById(R.id.switchModeButton);

            updateName();
            updateTrainer();
            updateType();

            if(editMode)
            {
                switchbutton.setVisibility(View.GONE);
            }
            else
            {
                switchbutton.setVisibility(View.VISIBLE);
            }

            ((ImageButton) view).setImageResource((Boolean.TRUE.equals(editMode) ? R.drawable.ic_pokeball_checkermark_simple_vec : R.drawable.ic_pokeball_edit_vec));
        }
        else
        {
            createSwapFragment();
        }
    }

    public void updateName()
    {
        if (pokemonName.isFocusable())
        {
            if (!pokemonName.getText().toString().equals(""))
            {
                pokemonName.setClickable(false);
                pokemonName.setFocusable(false);

                pokemon.setName(pokemonName.getText().toString());
                STORAGE.update(pokemon);
                STORAGE.saveAll(getBaseContext());

                makeUpdatedSettingsToast();
            }
            else
            {
                Toast.makeText(this, "Name can't be empty!", Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            pokemonName.setClickable(true);
            pokemonName.setFocusable(true);
            pokemonName.setFocusableInTouchMode(true);

            pokemonName.requestFocus();
        }
    }

    public void updateTrainer()
    {
        if (trainerSpinner.isEnabled())
        {
            trainerSpinner.setEnabled(false);
            pokemon.setTrainer((Trainer) trainerSpinner.getSelectedItem());
            STORAGE.update(pokemon);
            STORAGE.saveAll(getBaseContext());
            makeUpdatedSettingsToast();
        }
        else
        {
            trainerSpinner.setEnabled(true);
        }
    }

    public void updateType()
    {
        ImageButton button = findViewById(R.id.editTypeButton);
        button.setVisibility((button.getVisibility() == View.VISIBLE ? View.INVISIBLE : View.VISIBLE));

        pokemon.setType(currentType);
        STORAGE.update(pokemon);
        STORAGE.saveAll(getBaseContext());
    }

    public void onEditTypeButtonClicked(View view)
    {
        switch (currentType)
        {
            case POISON:
                pokemonType.setImageResource(R.drawable.ic_type_water_selected);
                currentType = Type.WATER;
                updateToolbarColor();
                break;

            case WATER:
                pokemonType.setImageResource(R.drawable.ic_type_fire_selected);
                currentType = Type.FIRE;
                updateToolbarColor();
                break;

            case FIRE:
                pokemonType.setImageResource(R.drawable.ic_type_poison_selected);
                currentType = Type.POISON;
                updateToolbarColor();
                break;

            default:
                break;
        }
    }

    public void onSwapChecked(View view)
    {
        pokemon.setSwapAllow(swapAllowedChecker.isChecked());
        STORAGE.update(pokemon);
        STORAGE.saveAll(getBaseContext());
    }

    public void onSwapListRadioButtonClicked(View view)
    {
        if (swapFragment != null)
        {
            swapFragment.onSwapListRadioButtonClicked(view);
        }
    }

    public void onSwapExecuteButtonClicked(View view)
    {
        if (swapFragment != null)
        {
            swapFragment.onSwapExecuteButtonClicked(view);
        }
    }
}
