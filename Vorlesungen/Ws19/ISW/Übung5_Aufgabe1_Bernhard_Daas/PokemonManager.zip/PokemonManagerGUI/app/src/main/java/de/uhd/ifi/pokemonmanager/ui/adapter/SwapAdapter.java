package de.uhd.ifi.pokemonmanager.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import java.util.List;
import java.util.Objects;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;

import static java.util.stream.Collectors.toList;


public class SwapAdapter extends Adapter<SwapHolder>
{
    private LayoutInflater inflater;
    private Pokemon pokemon;
    private List<Swap> originalData;
    private List<Swap> filteredData;

    public SwapAdapter(final Context context, final Pokemon pokemon)
    {
        this.inflater = LayoutInflater.from(context);
        this.pokemon = pokemon;
        this.originalData = pokemon.getSwaps();
        this.filteredData = this.originalData.stream().filter(Objects::nonNull).collect(toList());
    }

    @NonNull
    @Override
    public SwapHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        final View itemView = inflater.inflate(R.layout.listitem_swap, parent, false);
        return new SwapHolder(itemView);
    }

    @Override
    public  void onBindViewHolder(@NonNull SwapHolder holder, int position)
    {
        holder.setSwap(pokemon, filteredData.get(position));
    }

    @Override
    public int getItemCount()
    {
        return filteredData.size();
    }

    public void refresh()
    {
        this.originalData = pokemon.getSwaps();
        this.filteredData = originalData.stream().filter(Objects::nonNull).collect(toList());
        notifyDataSetChanged();;
    }
}


class SwapHolder extends ViewHolder
{
    private final TextView swapText;
    private final TextView swapDate;

    SwapHolder(@NonNull View itemView)
    {
        super(itemView);
        swapText = itemView.findViewById(R.id.swapText);
        swapDate = itemView.findViewById(R.id.swapTime);
        itemView.setTag(this);
    }

    void setSwap(Pokemon pokemon, Swap swap)
    {
        if (swap != null && pokemon != null)
        {
            String date = "Time: " + swap.getDate();
            StringBuilder textBuilder = new StringBuilder();
            textBuilder.append("Traded with ");

            if (swap.getSourcePokemon() != null && swap.getTargetPokemon() != null)
            {
                String sourcePokemon = swap.getSourcePokemon().getName();
                String targetPokemon = swap.getTargetPokemon().getName();
                String partner = (pokemon.getId() == swap.getSourcePokemon().getId() ? targetPokemon : sourcePokemon);

                textBuilder.append(partner);
            }
            else
            {
                textBuilder.append("[Deleted]");
            }

            swapText.setText(textBuilder.toString());
            swapDate.setText(date);
        }
    }
}