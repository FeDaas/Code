package de.uhd.ifi.pokemonmanager.ui.util;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;

import java.util.ArrayList;
import java.util.List;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;
import de.uhd.ifi.pokemonmanager.storage.SerialStorage;
import de.uhd.ifi.pokemonmanager.ui.DetailActivity;
import de.uhd.ifi.pokemonmanager.ui.adapter.SwapExecuteAdapter;


public class SwapFragment extends DialogFragment
{
    private static final SerialStorage STORAGE = SerialStorage.getInstance();

    private RecyclerView possibleSwapsList;
    private Pokemon pokemon;
    private List<Pokemon> allowedSwapPartners;

    private RadioButton checkedButton = null;
    private Button swapButton = null;

    public SwapFragment()
    {
        // Empty constructor is required for DialogFragment
    }

    public static SwapFragment newInstance(Pokemon pokemon)
    {
        SwapFragment frag = new SwapFragment();
        Bundle args = new Bundle();
        args.putParcelable("pokemon", pokemon);
        frag.setArguments(args);

        return frag;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        return inflater.inflate(R.layout.fragment_swap, container);
    }

    private static List<Pokemon> getAllowedSwapPartners(Pokemon pokemon, List<Pokemon> pokemons)
    {
        List<Pokemon> allowedSwapPartners = new ArrayList<>();

        for (Pokemon currentPokemon : pokemons)
        {
            if (currentPokemon != null
                    && currentPokemon.isSwapAllow()
                    && currentPokemon.getId() != pokemon.getId()
                    && currentPokemon.getTrainer().getId() != pokemon.getTrainer().getId())
            {
                allowedSwapPartners.add(currentPokemon);
            }
        }

        return allowedSwapPartners;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        if (getArguments() != null)
        {
            pokemon = getArguments().getParcelable("pokemon");
        }
        possibleSwapsList = view.findViewById(R.id.possibleSwapsList);
        swapButton = view.findViewById(R.id.swapExecuteButton);
        allowedSwapPartners = getAllowedSwapPartners(pokemon, STORAGE.getAllPokemon());


        SwapExecuteAdapter swapExecuteAdapter = new SwapExecuteAdapter(getContext(), allowedSwapPartners);
        final RecyclerView.LayoutManager manager = RecyclerViewUtil.createLayoutManager(getContext());

        possibleSwapsList.setLayoutManager(manager);
        possibleSwapsList.setAdapter(swapExecuteAdapter);
    }

    public void onSwapListRadioButtonClicked(View view)
    {
        if (view != null && checkedButton != view)
        {
            if (checkedButton == null)
            {
                checkedButton = (RadioButton) view;
                swapButton.setVisibility(View.VISIBLE);
            }
            else
            {
                checkedButton.setChecked(false);
                checkedButton = (RadioButton) view;
            }
        }
    }

    private void executeSwap(Pokemon pokemon1, Pokemon pokemon2)
    {
        Swap swap = new Swap();
        swap.execute(pokemon1, pokemon2);

        STORAGE.update(pokemon1);
        STORAGE.update(pokemon2);
        STORAGE.update(swap);

        STORAGE.saveAll(getActivity().getBaseContext());
    }

    public void onSwapExecuteButtonClicked(View view)
    {
        CardView pokemonCard = (CardView) checkedButton.getParent().getParent();
        int id = possibleSwapsList.getChildAdapterPosition(pokemonCard);

        executeSwap(pokemon, allowedSwapPartners.get(id));
        ((DetailActivity) getActivity()).removeFragmentAndUpdate();
    }
}