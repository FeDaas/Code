package de.uhd.ifi.pokemonmanager.ui.adapter.singleSelection;

public interface IndexedAdapter<T> {
    T getElementByPosition(int position);
}
