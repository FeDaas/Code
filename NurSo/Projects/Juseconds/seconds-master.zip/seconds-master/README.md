# Seconds
Seconds is a 2D sidescroller/ speedrunner game build in the Godot Engine.
